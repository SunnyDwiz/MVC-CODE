﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HtmlHelpers.Models;
namespace HtmlHelpers.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            var temp = TempData["States"];
            TempData.Keep("States");
           // var temp2 = TempData["States"];
            UserModel userModel=new UserModel();
            var selectItem=new SelectListItem() {Text = "Admin",Value ="Admin"};
            userModel.Roles.Add(selectItem);
            var selectItem1 = new SelectListItem() { Text = "User", Value = "User" };
            userModel.Roles.Add(selectItem1);
            return View(userModel);
        }
        [HttpPost]
        public ActionResult Index(UserModel model)
        {
            var temp = TempData["States"];
            return RedirectToAction("SecondTime");
        }
        public ActionResult SecondTime()
        {
            var temp = TempData["States"];
            return RedirectToAction("ThirdTime","Home");
        }

       
    }
}