﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Web;

namespace CustomAndInlineHelper.Models
{
    public class EmpModel
    {
        public string EmployeeName { get; set; }
        public string Role { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
    }
}