﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Validations.Models;

namespace Validations.Controllers
{
    public class UserLoginController : Controller
    {
        // GET: UserLogin
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginModel userModel)
        {
            if (ModelState.IsValid)
            {
                if (userModel.UserName == "test" && userModel.Password == "test")
                {
                    Session["UserID"] = "test";
                    return RedirectToAction("Index", "Account");
                }
                ModelState.AddModelError("","Invalid Login Attempt");
                return View(userModel);
            }
            return View(userModel);
        }
    }
}