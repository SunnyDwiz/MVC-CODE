﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Validations.Models;

namespace Validations.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Employee emp)
        {
            if (ModelState.IsValid)
            {
                RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Registration()
        {
            return View();
        }
        [Route("Home/ContactUs")]
        public ActionResult Contact()
        {
            ViewBag.Message = "Thank you for Contact US";
            return View();
        }
    }
}