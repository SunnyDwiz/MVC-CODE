﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Web;
using System.Web.Mvc;

namespace HtmlHelpers
{
    public static class CustomHelper
    {
        public static MvcHtmlString MyButton(this HtmlHelper helper,string value, string name)
        {
            string btn = "<input type='submit' value='" + value + "' name='" + name + "'/>";
            return new MvcHtmlString(btn);
        }
        public static MvcHtmlString MyLabel(this HtmlHelper helper, string content)
        {
            string lbl = "<label>"+content+"</label>";
            return new MvcHtmlString(lbl);
        }
    }
}