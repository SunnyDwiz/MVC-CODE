﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HtmlHelpers.Models;

namespace HtmlHelpers.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var list=new List<string>();
            list.Add("Hyderabad");
            list.Add("Bangalore");
            list.Add("Pune");
           TempData["States"]= list;
            return RedirectToAction("Index","Account");
        }
        public ActionResult ThirdTime()
        {
            var temp = TempData["States"];
            return RedirectToAction("ForthTime");
        }
        public ActionResult ForthTime()
        {
            var temp = TempData["States"];
            return View();
        }

        public ActionResult ViewWithLayout()
        {
            return View();
        }

        public ActionResult AboutUs()
        {
            return View();
        }
        public ActionResult Services()
        {
            return View();
        }
        public ActionResult ContactUs()
        {
            return View();
        }
        public ActionResult Feedback()
        {
            return View();
        }

    }
}